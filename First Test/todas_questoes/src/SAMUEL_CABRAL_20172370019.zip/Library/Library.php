<?php

namespace Library;

class Library
{
  public static function sort($codes)
  {
    // TODO
    return sort($codes, SORT_LOCALE_STRING);
    
  }
}
